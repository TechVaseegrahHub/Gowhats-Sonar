<?php
/**
 * Plugin Name: GoWhats WooCommerce Restock Alerts
 * Plugin URI: https://bot.gowhats.in
 * Description: Shows a WhatsApp restock form on out-of-stock WooCommerce products and syncs subscriptions to GoWhats.
 * Version: 1.3.1
 * Author: GoWhats
 * Author URI: https://bot.gowhats.in
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Text Domain: gowhats-woocommerce-restock
 * WC requires at least: 6.0
 * WC tested up to: 10.0
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('GoWhats_WooCommerce_Restock')) {
    final class GoWhats_WooCommerce_Restock {
        private const VERSION = '1.3.1';
        private const OPTION_KEY = 'gowhats_woocommerce_restock_settings';
        private const NONCE_ACTION = 'gowhats_woocommerce_restock';

        public function __construct() {
            add_action('plugins_loaded', [$this, 'bootstrap']);
        }

        public function bootstrap() {
            if (!class_exists('WooCommerce')) {
                add_action('admin_notices', [$this, 'render_missing_woocommerce_notice']);
                return;
            }

            add_action('admin_menu', [$this, 'register_admin_menu']);
            add_action('admin_init', [$this, 'register_settings']);
            add_action('wp_enqueue_scripts', [$this, 'enqueue_frontend_assets']);
            add_action('woocommerce_single_product_summary', [$this, 'render_product_widget'], 31);
            add_action('wp_ajax_gowhats_restock_subscribe', [$this, 'handle_ajax_subscribe']);
            add_action('wp_ajax_nopriv_gowhats_restock_subscribe', [$this, 'handle_ajax_subscribe']);
            add_action('wp_ajax_gowhats_restock_status', [$this, 'handle_ajax_status']);
            add_action('wp_ajax_nopriv_gowhats_restock_status', [$this, 'handle_ajax_status']);
            add_action('woocommerce_product_set_stock', [$this, 'handle_stock_object_update']);
            add_action('woocommerce_variation_set_stock', [$this, 'handle_stock_object_update']);
            add_action('woocommerce_product_set_stock_status', [$this, 'handle_stock_status_update'], 10, 3);
            add_action('woocommerce_variation_set_stock_status', [$this, 'handle_stock_status_update'], 10, 3);
            add_shortcode('gowhats_restock_widget', [$this, 'render_shortcode']);
        }

        public function render_missing_woocommerce_notice() {
            if (!current_user_can('activate_plugins')) {
                return;
            }

            echo '<div class="notice notice-error"><p>GoWhats WooCommerce Restock Alerts requires WooCommerce to be installed and active.</p></div>';
        }

        public function register_admin_menu() {
            add_submenu_page(
                'woocommerce',
                'GoWhats Restock',
                'GoWhats Restock',
                'manage_woocommerce',
                'gowhats-woocommerce-restock',
                [$this, 'render_settings_page']
            );
        }

        public function register_settings() {
            register_setting(
                'gowhats_woocommerce_restock_group',
                self::OPTION_KEY,
                [$this, 'sanitize_settings']
            );
        }

        public function sanitize_settings($input) {
            $defaults = $this->get_default_settings();
            $raw = is_array($input) ? $input : [];

            return [
                'subscribe_url' => esc_url_raw($raw['subscribe_url'] ?? ''),
                'status_url' => esc_url_raw($raw['status_url'] ?? ''),
                'stock_update_url' => esc_url_raw($raw['stock_update_url'] ?? ''),
                'shared_secret' => sanitize_text_field($raw['shared_secret'] ?? ''),
                'cta_label' => sanitize_text_field($raw['cta_label'] ?? $defaults['cta_label']),
                'phone_placeholder' => sanitize_text_field($raw['phone_placeholder'] ?? $defaults['phone_placeholder']),
                'helper_text' => sanitize_textarea_field($raw['helper_text'] ?? $defaults['helper_text']),
                'success_message' => sanitize_textarea_field($raw['success_message'] ?? $defaults['success_message']),
                'default_country' => strtoupper(sanitize_text_field($raw['default_country'] ?? $defaults['default_country'])),
            ];
        }

        private function get_default_settings() {
            return [
                'subscribe_url' => '',
                'status_url' => '',
                'stock_update_url' => '',
                'shared_secret' => '',
                'cta_label' => 'Request stock',
                'phone_placeholder' => 'Enter your WhatsApp number',
                'helper_text' => 'Get notified on WhatsApp when the product comes back in stock.',
                'success_message' => 'You are successfully subscribed for this restock alert.',
                'default_country' => 'IN',
            ];
        }

        private function get_settings() {
            return wp_parse_args(get_option(self::OPTION_KEY, []), $this->get_default_settings());
        }

        private function is_configured($settings = null) {
            $settings = is_array($settings) ? $settings : $this->get_settings();

            return !empty($settings['subscribe_url']) &&
                !empty($settings['stock_update_url']) &&
                !empty($settings['shared_secret']);
        }

        public function render_settings_page() {
            if (!current_user_can('manage_woocommerce')) {
                return;
            }

            $settings = $this->get_settings();
            ?>
            <div class="wrap">
                <h1>GoWhats WooCommerce Restock</h1>
                <p>Paste the values from your GoWhats WooCommerce Restock Alerts panel, then save.</p>

                <form method="post" action="options.php">
                    <?php settings_fields('gowhats_woocommerce_restock_group'); ?>
                    <table class="form-table" role="presentation">
                        <tr>
                            <th scope="row"><label for="gowhats_subscribe_url">Subscribe URL</label></th>
                            <td>
                                <input name="<?php echo esc_attr(self::OPTION_KEY); ?>[subscribe_url]" id="gowhats_subscribe_url" type="url" class="large-text" value="<?php echo esc_attr($settings['subscribe_url']); ?>">
                                <p class="description">Copy this from GoWhats Restock Alerts > Woo Plugin Setup.</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="gowhats_status_url">Status URL</label></th>
                            <td>
                                <input name="<?php echo esc_attr(self::OPTION_KEY); ?>[status_url]" id="gowhats_status_url" type="url" class="large-text" value="<?php echo esc_attr($settings['status_url']); ?>">
                                <p class="description">Optional, but recommended for duplicate checks.</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="gowhats_stock_update_url">Stock Update URL</label></th>
                            <td>
                                <input name="<?php echo esc_attr(self::OPTION_KEY); ?>[stock_update_url]" id="gowhats_stock_update_url" type="url" class="large-text" value="<?php echo esc_attr($settings['stock_update_url']); ?>">
                                <p class="description">GoWhats uses this when WooCommerce stock changes from out of stock to in stock.</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="gowhats_shared_secret">Shared Secret</label></th>
                            <td>
                                <input name="<?php echo esc_attr(self::OPTION_KEY); ?>[shared_secret]" id="gowhats_shared_secret" type="text" class="large-text" value="<?php echo esc_attr($settings['shared_secret']); ?>">
                                <p class="description">Keep this value the same in GoWhats and WordPress.</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="gowhats_cta_label">CTA Button</label></th>
                            <td><input name="<?php echo esc_attr(self::OPTION_KEY); ?>[cta_label]" id="gowhats_cta_label" type="text" class="regular-text" value="<?php echo esc_attr($settings['cta_label']); ?>"></td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="gowhats_phone_placeholder">Phone Placeholder</label></th>
                            <td><input name="<?php echo esc_attr(self::OPTION_KEY); ?>[phone_placeholder]" id="gowhats_phone_placeholder" type="text" class="regular-text" value="<?php echo esc_attr($settings['phone_placeholder']); ?>"></td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="gowhats_helper_text">Helper Text</label></th>
                            <td><textarea name="<?php echo esc_attr(self::OPTION_KEY); ?>[helper_text]" id="gowhats_helper_text" class="large-text" rows="3"><?php echo esc_textarea($settings['helper_text']); ?></textarea></td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="gowhats_success_message">Success Message</label></th>
                            <td><textarea name="<?php echo esc_attr(self::OPTION_KEY); ?>[success_message]" id="gowhats_success_message" class="large-text" rows="3"><?php echo esc_textarea($settings['success_message']); ?></textarea></td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="gowhats_default_country">Default Country</label></th>
                            <td>
                                <input name="<?php echo esc_attr(self::OPTION_KEY); ?>[default_country]" id="gowhats_default_country" type="text" class="small-text" maxlength="4" value="<?php echo esc_attr($settings['default_country']); ?>">
                                <p class="description">Examples: IN, US, AE, SG.</p>
                            </td>
                        </tr>
                    </table>
                    <?php submit_button('Save GoWhats Restock Settings'); ?>
                </form>

                <hr />
                <h2>Theme fallback</h2>
                <p>If your theme or Elementor single-product template does not show the widget automatically, place this shortcode in the product template:</p>
                <code>[gowhats_restock_widget]</code>
            </div>
            <?php
        }

        public function enqueue_frontend_assets() {
            if (!function_exists('is_product') || !is_product()) {
                return;
            }

            $product = wc_get_product(get_the_ID());
            if (!$product instanceof WC_Product || !$this->supports_product($product)) {
                return;
            }

            $settings = $this->get_settings();

            wp_enqueue_style(
                'gowhats-woocommerce-restock',
                plugin_dir_url(__FILE__) . 'assets/css/frontend.css',
                [],
                self::VERSION
            );

            wp_enqueue_script(
                'gowhats-woocommerce-restock',
                plugin_dir_url(__FILE__) . 'assets/js/frontend.js',
                ['jquery'],
                self::VERSION,
                true
            );

            wp_localize_script(
                'gowhats-woocommerce-restock',
                'GoWhatsWooRestock',
                [
                    'ajaxUrl' => admin_url('admin-ajax.php'),
                    'nonce' => wp_create_nonce(self::NONCE_ACTION),
                    'isConfigured' => $this->is_configured($settings),
                    'settings' => [
                        'ctaLabel' => $settings['cta_label'],
                        'phonePlaceholder' => $settings['phone_placeholder'],
                        'helperText' => $settings['helper_text'],
                        'successMessage' => $settings['success_message'],
                        'defaultCountry' => $settings['default_country'],
                        'hostedPageUrl' => $this->build_hosted_form_url($settings['subscribe_url']),
                    ],
                    'strings' => [
                        'missingPhone' => 'Enter your WhatsApp number.',
                        'submitting' => 'Submitting...',
                        'subscriptionSaved' => $settings['success_message'],
                        'alreadySubscribed' => 'This number is already waiting for a restock alert.',
                        'notConfigured' => 'GoWhats restock plugin is not configured yet.',
                        'requestFailed' => 'Unable to submit the restock request right now.',
                        'productInStock' => 'This product is already in stock.',
                        'mobileHostedHint' => 'Tap below to open the mobile restock form.',
                    ],
                    'product' => [
                        'id' => (string) $product->get_id(),
                        'type' => $product->get_type(),
                        'title' => $product->get_name(),
                        'url' => get_permalink($product->get_id()),
                        'imageUrl' => $this->get_product_image_url($product),
                        'isInStock' => $product->is_in_stock(),
                    ],
                ]
            );
        }

        public function render_shortcode() {
            ob_start();
            $this->render_widget_markup();
            return ob_get_clean();
        }

        public function render_product_widget() {
            $this->render_widget_markup();
        }

        private function render_widget_markup() {
            if (!function_exists('is_product') || !is_product()) {
                return;
            }

            $product = wc_get_product(get_the_ID());
            if (!$product instanceof WC_Product || !$this->supports_product($product)) {
                return;
            }

            $settings = $this->get_settings();
            $is_simple_out = $product->is_type('simple') && !$product->is_in_stock();
            $should_show = $product->is_type('variable') || $is_simple_out;
            ?>
            <div
                id="gowhats-restock-root"
                class="gowhats-restock-root<?php echo $should_show ? '' : ' is-hidden'; ?>"
                data-product-id="<?php echo esc_attr($product->get_id()); ?>"
                data-product-type="<?php echo esc_attr($product->get_type()); ?>"
            >
                <div class="gowhats-restock-card">
                    <div class="gowhats-restock-card__header">
                        <div class="gowhats-restock-card__badge">WhatsApp Restock Alerts</div>
                        <p class="gowhats-restock-card__help"><?php echo esc_html($settings['helper_text']); ?></p>
                    </div>

                    <div class="gowhats-restock-card__form">
                        <input
                            id="gowhats-restock-phone"
                            type="tel"
                            inputmode="tel"
                            placeholder="<?php echo esc_attr($settings['phone_placeholder']); ?>"
                            class="gowhats-restock-card__input"
                        />
                        <button type="button" id="gowhats-restock-submit" class="gowhats-restock-card__button">
                            <?php echo esc_html($settings['cta_label']); ?>
                        </button>
                    </div>

                    <p id="gowhats-restock-mobile-note" class="gowhats-restock-card__mobile-note" hidden>
                        Tap below to open the mobile restock form.
                    </p>

                    <div id="gowhats-restock-feedback" class="gowhats-restock-card__feedback" aria-live="polite"></div>
                </div>
            </div>
            <?php
        }

        private function supports_product($product) {
            return $product instanceof WC_Product &&
                in_array($product->get_type(), ['simple', 'variable'], true);
        }

        public function handle_ajax_subscribe() {
            check_ajax_referer(self::NONCE_ACTION, 'nonce');

            $settings = $this->get_settings();
            if (!$this->is_configured($settings)) {
                wp_send_json_error(['message' => 'GoWhats restock plugin is not configured yet.'], 500);
            }

            $product_id = absint($_POST['productId'] ?? 0);
            $variation_id = absint($_POST['variationId'] ?? 0);
            $phone = sanitize_text_field(wp_unslash($_POST['phoneNumber'] ?? ''));

            if (!$product_id || !$phone) {
                wp_send_json_error(['message' => 'Product and phone number are required.'], 400);
            }

            $selected_product = wc_get_product($variation_id ?: $product_id);
            $parent_product = wc_get_product($product_id);

            if (!$parent_product instanceof WC_Product || !$selected_product instanceof WC_Product) {
                wp_send_json_error(['message' => 'Product not found.'], 404);
            }

            if ($selected_product->is_in_stock()) {
                wp_send_json_error(['message' => 'This product is already in stock.'], 400);
            }

            $payload = [
                'phoneNumber' => $this->normalize_phone($phone, $settings['default_country']),
                'customerName' => sanitize_text_field(wp_unslash($_POST['customerName'] ?? '')),
                'productId' => (string) $product_id,
                'variationId' => $variation_id ? (string) $variation_id : '',
                'productTitle' => $parent_product->get_name(),
                'variationTitle' => $variation_id ? $this->build_variation_label($selected_product) : '',
                'productUrl' => get_permalink($product_id),
                'productImageUrl' => $this->get_product_image_url($selected_product, $parent_product),
                'siteUrl' => home_url('/'),
                'pluginVersion' => self::VERSION,
            ];

            $result = $this->perform_remote_json_request($settings['subscribe_url'], 'POST', $payload, $settings['shared_secret']);

            if (is_wp_error($result)) {
                wp_send_json_error(['message' => $result->get_error_message()], 500);
            }

            $message = !empty($result['message']) ? $result['message'] : $settings['success_message'];

            wp_send_json_success([
                'message' => $message,
                'alreadySubscribed' => !empty($result['alreadySubscribed']),
                'raw' => $result,
            ]);
        }

        public function handle_ajax_status() {
            check_ajax_referer(self::NONCE_ACTION, 'nonce');

            $settings = $this->get_settings();
            if (empty($settings['status_url']) || empty($settings['shared_secret'])) {
                wp_send_json_error(['message' => 'Status check is not configured.'], 400);
            }

            $product_id = absint($_POST['productId'] ?? 0);
            $variation_id = absint($_POST['variationId'] ?? 0);
            $phone = sanitize_text_field(wp_unslash($_POST['phoneNumber'] ?? ''));

            if (!$product_id || !$phone) {
                wp_send_json_error(['message' => 'Product and phone number are required.'], 400);
            }

            $query_args = [
                'productId' => (string) $product_id,
                'variationId' => $variation_id ? (string) $variation_id : '',
                'phoneNumber' => $this->normalize_phone($phone, $settings['default_country']),
            ];

            $url = add_query_arg($query_args, $settings['status_url']);
            $result = $this->perform_remote_json_request($url, 'GET', null, $settings['shared_secret']);

            if (is_wp_error($result)) {
                wp_send_json_error(['message' => $result->get_error_message()], 500);
            }

            wp_send_json_success($result);
        }

        public function handle_stock_object_update($product) {
            if ($product instanceof WC_Product) {
                $this->send_stock_update($product);
            }
        }

        public function handle_stock_status_update($product_id, $stock_status, $product) {
            if ($product instanceof WC_Product) {
                $this->send_stock_update($product);
                return;
            }

            $resolved_product = wc_get_product($product_id);
            if ($resolved_product instanceof WC_Product) {
                $this->send_stock_update($resolved_product);
            }
        }

        private function send_stock_update($product) {
            $settings = $this->get_settings();
            if (!$this->is_configured($settings) || empty($settings['stock_update_url'])) {
                return;
            }

            if (!$product instanceof WC_Product || !$product->is_in_stock()) {
                return;
            }

            $product_id = $product instanceof WC_Product_Variation ? $product->get_parent_id() : $product->get_id();
            $variation_id = $product instanceof WC_Product_Variation ? $product->get_id() : 0;
            $parent_product = wc_get_product($product_id);

            if (!$parent_product instanceof WC_Product) {
                return;
            }

            $stock_quantity = $product->get_stock_quantity();
            if ($stock_quantity === null && $product->is_in_stock()) {
                $stock_quantity = 1;
            }

            $payload = [
                'productId' => (string) $product_id,
                'variationId' => $variation_id ? (string) $variation_id : '',
                'stockQuantity' => $stock_quantity === null ? '' : (int) $stock_quantity,
                'inStock' => (bool) $product->is_in_stock(),
                'productTitle' => $parent_product->get_name(),
                'variationTitle' => $variation_id ? $this->build_variation_label($product) : '',
                'productUrl' => get_permalink($product_id),
                'productImageUrl' => $this->get_product_image_url($product, $parent_product),
            ];

            $this->perform_remote_json_request($settings['stock_update_url'], 'POST', $payload, $settings['shared_secret']);
        }

        private function perform_remote_json_request($url, $method = 'POST', $payload = null, $shared_secret = '') {
            $args = [
                'method' => strtoupper($method),
                'timeout' => 20,
                'headers' => [
                    'Content-Type' => 'application/json',
                    'Accept' => 'application/json',
                    'x-gowhats-secret' => $shared_secret,
                ],
            ];

            if ($payload !== null) {
                $args['body'] = wp_json_encode($payload);
            }

            $response = wp_remote_request($url, $args);

            if (is_wp_error($response)) {
                return $response;
            }

            $status_code = wp_remote_retrieve_response_code($response);
            $body = wp_remote_retrieve_body($response);
            $decoded = json_decode($body, true);

            if ($status_code >= 400) {
                $message = is_array($decoded) && !empty($decoded['error'])
                    ? $decoded['error']
                    : 'GoWhats request failed.';

                return new WP_Error('gowhats_remote_error', $message);
            }

            if (!is_array($decoded)) {
                return new WP_Error('gowhats_invalid_response', 'Invalid response from GoWhats.');
            }

            if (array_key_exists('success', $decoded) && !$decoded['success']) {
                $message = !empty($decoded['error']) ? $decoded['error'] : 'GoWhats request failed.';
                return new WP_Error('gowhats_unsuccessful_response', $message);
            }

            return $decoded;
        }

        private function build_variation_label($product) {
            if (!$product instanceof WC_Product_Variation) {
                return '';
            }

            $parts = [];
            foreach ($product->get_attributes() as $value) {
                $clean = trim((string) $value);
                if ($clean !== '') {
                    $parts[] = $clean;
                }
            }

            return implode(' / ', $parts);
        }

        private function get_product_image_url($preferred_product, $fallback_product = null) {
            $products = array_filter([$preferred_product, $fallback_product], function ($product) {
                return $product instanceof WC_Product;
            });

            foreach ($products as $product) {
                $image_id = $product->get_image_id();
                if ($image_id) {
                    $url = wp_get_attachment_image_url($image_id, 'full');
                    if ($url) {
                        return $url;
                    }
                }
            }

            return '';
        }

        private function build_hosted_form_url($subscribe_url) {
            $subscribe_url = trim((string) $subscribe_url);
            if ($subscribe_url === '') {
                return '';
            }

            $parts = wp_parse_url($subscribe_url);
            if (empty($parts['host']) || empty($parts['path'])) {
                return '';
            }

            if (!preg_match('#/api/woocommerce-restock/([^/]+)/subscribe/?$#', $parts['path'], $matches)) {
                return '';
            }

            $scheme = !empty($parts['scheme']) ? $parts['scheme'] : 'https';
            $port = !empty($parts['port']) ? ':' . $parts['port'] : '';

            return sprintf(
                '%s://%s%s/restock/woocommerce/%s',
                $scheme,
                $parts['host'],
                $port,
                $matches[1]
            );
        }

        private function normalize_phone($phone, $default_country) {
            $digits = preg_replace('/\D+/', '', (string) $phone);
            if ($digits === '') {
                return '';
            }

            if (strlen($digits) > 10) {
                return $digits;
            }

            $dial_codes = [
                'IN' => '91',
                'US' => '1',
                'CA' => '1',
                'AE' => '971',
                'SG' => '65',
                'GB' => '44',
                'UK' => '44',
                'AU' => '61',
                'SA' => '966',
                'QA' => '974',
                'KW' => '965',
            ];

            $country = strtoupper(trim((string) $default_country));
            $dial_code = $dial_codes[$country] ?? '';

            if ($dial_code !== '' && strpos($digits, $dial_code) !== 0) {
                return $dial_code . ltrim($digits, '0');
            }

            return $digits;
        }
    }

    new GoWhats_WooCommerce_Restock();
}
