GoWhats WooCommerce Restock Alerts
=================================

Install
-------
1. Upload the plugin ZIP in WordPress: Plugins > Add Plugin > Upload Plugin
2. Activate the plugin
3. Open WooCommerce > GoWhats Restock
4. Paste these restock values from GoWhats into the WordPress plugin:
   - Subscribe URL
   - Status URL
   - Stock Update URL
   - Shared Secret
5. Save settings

What it does
------------
- Shows a restock WhatsApp form on out-of-stock simple products
- Shows the form for out-of-stock variations on variable products
- Proxies requests securely from WooCommerce to GoWhats
- Sends stock update events to GoWhats when products are restocked

Fallback
--------
If your theme or Elementor product template does not display the widget automatically, add this shortcode:

[gowhats_restock_widget]
