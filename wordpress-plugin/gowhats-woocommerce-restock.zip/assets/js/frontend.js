(function ($) {
  const config = window.GoWhatsWooRestock || {};
  const root = document.getElementById('gowhats-restock-root');

  if (!root) {
    return;
  }

  const phoneInput = document.getElementById('gowhats-restock-phone');
  const submitButton = document.getElementById('gowhats-restock-submit');
  const feedback = document.getElementById('gowhats-restock-feedback');
  const mobileNote = document.getElementById('gowhats-restock-mobile-note');
  const settings = config.settings || {};
  const strings = config.strings || {};
  const product = config.product || {};

  let currentState = {
    productId: product.id || '',
    variationId: '',
    productTitle: product.title || '',
    variationTitle: '',
    productUrl: product.url || window.location.href,
    productImageUrl: product.imageUrl || '',
  };

  function shouldUseHostedMobilePage() {
    return Boolean(settings.hostedPageUrl) && window.matchMedia('(max-width: 600px)').matches;
  }

  function updateMobileMode() {
    const isHostedMobile = shouldUseHostedMobilePage();
    root.classList.toggle('is-hosted-mobile', isHostedMobile);

    if (mobileNote) {
      mobileNote.hidden = !isHostedMobile;
      mobileNote.textContent = strings.mobileHostedHint || 'Tap below to open the mobile restock form.';
    }
  }

  function buildHostedPageUrl() {
    if (!settings.hostedPageUrl) {
      return '';
    }

    const url = new URL(settings.hostedPageUrl, window.location.href);
    const params = new URLSearchParams({
      productId: currentState.productId || '',
      variationId: currentState.variationId || '',
      productTitle: currentState.productTitle || '',
      variationTitle: currentState.variationTitle || '',
      productUrl: currentState.productUrl || window.location.href,
      productImageUrl: currentState.productImageUrl || '',
      siteUrl: window.location.origin,
    });

    url.search = params.toString();
    return url.toString();
  }

  function setVisibility(visible) {
    root.classList.toggle('is-hidden', !visible);
  }

  function setFeedback(type, message) {
    feedback.className = 'gowhats-restock-card__feedback';

    if (!message) {
      feedback.textContent = '';
      return;
    }

    feedback.classList.add(`is-${type}`);
    feedback.textContent = message;
  }

  function buildVariationTitle(variation) {
    if (!variation || !variation.attributes) {
      return '';
    }

    return Object.keys(variation.attributes)
      .map((key) => variation.attributes[key])
      .filter(Boolean)
      .join(' / ');
  }

  function setSubmitting(submitting) {
    submitButton.disabled = submitting;
    submitButton.textContent = submitting
      ? (strings.submitting || 'Submitting...')
      : (settings.ctaLabel || 'Request stock');
  }

  function requestStatusCheck() {
    if (!config.isConfigured || !phoneInput.value.trim()) {
      return;
    }

    $.post(config.ajaxUrl, {
      action: 'gowhats_restock_status',
      nonce: config.nonce,
      productId: currentState.productId,
      variationId: currentState.variationId,
      phoneNumber: phoneInput.value.trim(),
    }).done(function (response) {
      if (response && response.success && response.data && response.data.alreadySubscribed) {
        setFeedback('info', strings.alreadySubscribed || 'This number is already waiting for a restock alert.');
      }
    });
  }

  function submitRestockRequest() {
    if (!config.isConfigured) {
      setFeedback('error', strings.notConfigured || 'GoWhats restock plugin is not configured yet.');
      return;
    }

    if (shouldUseHostedMobilePage()) {
      const hostedPageUrl = buildHostedPageUrl();
      if (hostedPageUrl) {
        window.location.assign(hostedPageUrl);
        return;
      }
    }

    const phoneNumber = (phoneInput.value || '').trim();
    if (!phoneNumber) {
      setFeedback('error', strings.missingPhone || 'Enter your WhatsApp number.');
      phoneInput.focus();
      return;
    }

    setSubmitting(true);
    setFeedback('', '');

    $.post(config.ajaxUrl, {
      action: 'gowhats_restock_subscribe',
      nonce: config.nonce,
      productId: currentState.productId,
      variationId: currentState.variationId,
      phoneNumber: phoneNumber,
      productTitle: currentState.productTitle,
      variationTitle: currentState.variationTitle,
      productUrl: currentState.productUrl,
      productImageUrl: currentState.productImageUrl,
    }).done(function (response) {
      if (!response) {
        setFeedback('error', strings.requestFailed || 'Unable to submit the restock request right now.');
        return;
      }

      if (response.success) {
        const message =
          (response.data && response.data.message) ||
          strings.subscriptionSaved ||
          'You are successfully subscribed for this restock alert.';

        setFeedback(response.data && response.data.alreadySubscribed ? 'info' : 'success', message);
        if (!response.data || !response.data.alreadySubscribed) {
          phoneInput.value = '';
        }
        return;
      }

      const errorMessage =
        (response.data && response.data.message) ||
        strings.requestFailed ||
        'Unable to submit the restock request right now.';

      setFeedback('error', errorMessage);
    }).fail(function (xhr) {
      const errorMessage =
        (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) ||
        strings.requestFailed ||
        'Unable to submit the restock request right now.';

      setFeedback('error', errorMessage);
    }).always(function () {
      setSubmitting(false);
    });
  }

  if (product.type === 'simple') {
    setVisibility(!product.isInStock);
  } else {
    setVisibility(false);

    const variationForm = $('form.variations_form');
    if (variationForm.length) {
      variationForm.on('found_variation', function (_event, variation) {
        if (!variation) {
          setVisibility(false);
          updateMobileMode();
          return;
        }

        currentState.variationId = String(variation.variation_id || '');
        currentState.variationTitle = buildVariationTitle(variation);
        currentState.productUrl = variation.permalink || product.url || window.location.href;
        currentState.productImageUrl =
          (variation.image && (variation.image.full_src || variation.image.src)) ||
          product.imageUrl ||
          '';

        setFeedback('', '');
        setVisibility(!variation.is_in_stock);
        updateMobileMode();

        if (variation.is_in_stock) {
          setFeedback('info', strings.productInStock || 'This product is already in stock.');
        }
      });

      variationForm.on('reset_data hide_variation', function () {
        currentState.variationId = '';
        currentState.variationTitle = '';
        currentState.productUrl = product.url || window.location.href;
        currentState.productImageUrl = product.imageUrl || '';
        setFeedback('', '');
        setVisibility(false);
        updateMobileMode();
      });
    }
  }

  phoneInput.setAttribute('placeholder', settings.phonePlaceholder || 'Enter your WhatsApp number');
  submitButton.textContent = settings.ctaLabel || 'Request stock';
  updateMobileMode();
  submitButton.addEventListener('click', submitRestockRequest);
  phoneInput.addEventListener('blur', requestStatusCheck);
  window.addEventListener('resize', updateMobileMode);
})(jQuery);
